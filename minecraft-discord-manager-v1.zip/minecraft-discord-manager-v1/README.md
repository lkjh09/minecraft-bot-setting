# Minecraft Discord Manager V1
Starter project.